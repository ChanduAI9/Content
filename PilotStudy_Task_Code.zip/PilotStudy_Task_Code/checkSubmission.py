import jsonlines
import csv

with jsonlines.open('sample_45_telugu_N190402.jsonl', mode='r') as fp:
    with open('N190402.jsonl', mode='w', newline='') as f:
        sample_data = csv.writer(f)
        for line in fp.iter():
            for key, value in line.items():
                sample_data.writerow([key, value])
