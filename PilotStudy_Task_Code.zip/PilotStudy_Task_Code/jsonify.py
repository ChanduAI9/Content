import jsonlines

final_submission = []
task_filename = 'sample_45.jsonl'
translations_filename = 'sample_set_45_telugu_n190402.txt'
lang = 'telugu'
UID = 'N190402'

#Read the translations from the translation file.
te_sent = open(translations_filename,'r',encoding='utf-8').read().splitlines()
#Read the source sentences

fp = jsonlines.open(task_filename, mode="r") 

for line_dict,sent in zip(fp.iter(),te_sent):
    #add the translated sentence for the corresponding english source sentence
    line_dict['te'] = sent
    #append each line_dict to a list
    final_submission.append(line_dict)
      
#Save the list of dictionary into jsonl format.
with jsonlines.open(task_filename[:-6]+'_'+lang+'_'+UID+'.jsonl', mode="w") as fp:
    fp.write_all(final_submission)

