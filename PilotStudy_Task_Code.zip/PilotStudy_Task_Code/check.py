import jsonlines

final_submission = []
task_filename = 'sample_45.jsonl'
translations_filename = 'sample_set_45_telugu_n190402.txt'
lang = 'telugu'
UID = 'A12345'

# Read the translations from the translation file.
te_sent = open(translations_filename, 'r', encoding='utf-8').read().splitlines()

# Read the source sentences.
with jsonlines.open(task_filename, mode='r') as fp:
    for line_dict, sent in zip(fp.iter(), te_sent):
        # Add the translated sentence for the corresponding English source sentence.
        line_dict['te'] = sent
        # Append each line_dict to a list.
        final_submission.append(line_dict)

# Save the list of dictionaries into JSONL format.
with jsonlines.open(task_filename[:-6] + '_' + lang + '_' + UID + '.jsonl', mode='w') as fp:
    fp.write_all(final_submission)
