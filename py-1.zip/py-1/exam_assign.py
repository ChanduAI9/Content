import pandas as pd
import numpy as np
from pprint import pprint

#data
read_data=pd.read_csv('exams.csv')
# print(read_data)

#dataframe
marks_data=pd.DataFrame(read_data)
print(marks_data)

# class Exams_Marks:

#     def exam_marks():
#         for assign_marks in marks_data['ASSIGN_M']:
#             print(assign_marks)
# response=Exams_Marks()
# print(response.exam_marks)

def exams_marks():
    if (marks_data['BRANCH']=='MME'):
        if(marks_data['ASSIGN_M']<18 && marks_data['TOTAL']<40):
            extra_marks=18-marks_data['ASSIGN_M']
            
exams_marks()

        
        