# Social-Media-Analytics


hw6_social.py - The skeleton code of the Social Media Analytics is ready in this python file.
hw6_social_tests.py - The testing of the Social Media Analytics is in this python file.