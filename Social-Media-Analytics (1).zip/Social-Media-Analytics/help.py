import numpy
import pandas as pd
import matplotlib
import nltk
print("all are installed")
d = pd.read_csv('politicaldata.csv')
    #df = pd.DataFrame(d)
print(d.head())