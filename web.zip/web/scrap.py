def scraping_data(input_url):
  try:
    url=input_url
    html=urlopen(url)
    soup=BeautifulSoup(html,'lxml')

    rows=soup.find_all('tr',class_='a')
    ch=['[',']','\r']
    tdata=[]
    data=[]
    for row in rows:
      row_td=str(row.find_all('td'))
     
      for c in ch:
        row_td=row_td.replace(c," ")
      cleantxt=BeautifulSoup(row_td,"lxml").get_text().split(", ")
      tdata.append(cleantxt)

    df=pd.DataFrame(tdata,columns=["Country","Total Covid Cases","Deaths"])
    # for  recovery_data in df:
    # df['recovery']=df['Total Covid Cases']-df['Deaths']
    # df['recovery']=pd.to_numeric(df['Total Covid Cases']-df['Deaths'])

    # print(df.head())
    df=df.dropna(axis=0)
    df=df.fillna(0,inplace=True)
    df['Total Covid Cases']=df['Total Covid Cases'].replace(","," ")
    # df['Total Covid Cases']=int(df['Total Covid Cases'])
    # df['recovery']=df['Total Covid Cases'].astype('int')-df['Deaths'].astype('int')
    df['Total Covid Cases']=df['Total Covid Cases'].astype('int')
    df['Deaths']=df['Deaths'].astype('int')
    # print(df.head(20))
    df['recovery']=df["Total Covid Cases"].sub(df["Deaths"])
    # print(df['Total Covid Cases'])
    print(df)
    # print(df.head())
  except Exception as e:
    return e
  
input="https://kkclasses.github.io/dsp.html"
scraping_data(input)