Rocknroll = True
Silence = False
a_guitar = 10
Tommy = 44136
Music = 170
the_music = input()
if the_music == a_guitar:
    print("Keep on rocking!")
    the_rhythm = input()
    if the_rhythm - Music == False:
        Tommy = 66
        print(Tommy)
        Music = 79
        Jamming = 78
        print(Music)
        print(Jamming)
        Tommy = 74
        print(Tommy)
#        They are dazzled audiences
        print(it)
        Rock = 86
        print(it)
        Tommy = 73
        print(it)
        # break
        print("Bring on the rock!")
    else:
        print("That ain't it, Chief")
        # break
