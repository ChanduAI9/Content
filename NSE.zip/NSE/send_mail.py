import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Set up the email message
msg = MIMEMultipart()
msg['From'] = 'n190893@rguktn.ac.in'
msg['To'] = 'n1@rguktn.ac.in'
msg['Subject'] = 'Test email'
body = 'This is a test email sent from Python.'
msg.attach(MIMEText(body, 'plain'))

# Connect to the SMTP server
smtp_server = 'smtp.example.com'
smtp_port = 587
smtp_username = 'sender@example.com'
smtp_password = 'password'
smtp_connection = smtplib.SMTP(smtp_server, smtp_port)
smtp_connection.starttls()
smtp_connection.login(smtp_username, smtp_password)

# Send the email
smtp_connection.sendmail(msg['From'], msg['To'], msg.as_string())

# Close the connection to the SMTP server
smtp_connection.quit()
