from nsepy import get_history
from datetime import date
import pandas as pd
import csv


shares_data=pd.read_csv('indian_companies_stocks.csv')

class stocks_data:

  def __init__(self):
    pass

  def shares_data(self):
    try:
      for i in shares_data['SYMBOL']:
        data_stocks=get_history(symbol=i,start=date(2023,3,1),end=date(2023,3,13))
      # quotes_data=get_quote(symbol)
        print(data_stocks)
        stocks_dataframe=pd.DataFrame(data_stocks)
        stocks_dataframe.to_csv(i+'.csv')

    except Exception as e:
      print(e)

if __name__=='__main__':
  s=stocks_data()
  # for i in s.shares_data:
  print(s.shares_data())