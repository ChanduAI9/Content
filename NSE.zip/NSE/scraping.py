import numpy as np

arr=np.array([[1,2,3],[4,5,6],[7,8,9]])

arr_2=np.array([[4,5,6],[8,9,0],[9,8,6]])

for j in np.nditer(arr_2):
    # print(j)
    pass

for i in np.nditer(arr,flags=['buffered'],op_dtypes=['S']):
    # print(i)
    pass


for idx,i in np.ndenumerate(arr):
    print(idx,i)

#Numpy array joining

